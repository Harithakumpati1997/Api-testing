export type RequestMethod = 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH' | 'HEAD' | 'OPTIONS';

export interface KeyValuePair {
  key: string;
  value: string;
  enabled: boolean;
}

export interface RequestData {
  id: string;
  name: string;
  url: string;
  method: RequestMethod;
  headers: KeyValuePair[];
  params: KeyValuePair[];
  body: string;
  createdAt: string;
  updatedAt?: string;
}

export interface ResponseData {
  status: number;
  statusText: string;
  headers: { key: string; value: string }[];
  body: any;
  time: number;
  size: number;
  contentType: string;
}