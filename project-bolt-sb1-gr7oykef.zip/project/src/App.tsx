import React from 'react';
import { Layout } from './components/Layout';
import APITester from './features/api-tester/APITester';
import { RequestProvider } from './context/RequestContext';

function App() {
  return (
    <RequestProvider>
      <Layout>
        <APITester />
      </Layout>
    </RequestProvider>
  );
}

export default App;