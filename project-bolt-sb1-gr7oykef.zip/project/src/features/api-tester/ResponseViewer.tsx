import React, { useState } from 'react';
import { useRequest } from '../../context/RequestContext';
import { Tab } from '../../components/Tab';
import { formatJson } from '../../utils/formatter';

export const ResponseViewer: React.FC = () => {
  const { response, isLoading } = useRequest();
  const [activeTab, setActiveTab] = useState<'body' | 'headers'>('body');

  if (isLoading) {
    return (
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex justify-center items-center h-60">
          <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-blue-600"></div>
          <span className="ml-3 text-gray-600">Sending request...</span>
        </div>
      </div>
    );
  }

  if (!response) {
    return (
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex flex-col justify-center items-center h-60 text-gray-500">
          <p className="text-lg mb-2">No Response Yet</p>
          <p className="text-sm">Send a request to see the response here</p>
        </div>
      </div>
    );
  }

  // Format the response status color
  const getStatusColor = (status: number) => {
    if (status >= 200 && status < 300) return 'bg-green-500';
    if (status >= 300 && status < 400) return 'bg-blue-500';
    if (status >= 400 && status < 500) return 'bg-yellow-500';
    if (status >= 500) return 'bg-red-500';
    return 'bg-gray-500';
  };

  // Format response body
  const formattedBody = () => {
    if (typeof response.body === 'object') {
      return formatJson(response.body);
    }
    return response.body;
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
      <div className="p-4 border-b border-gray-200">
        <div className="flex flex-wrap items-center gap-4">
          <div className="flex items-center">
            <div className={`px-3 py-1 rounded text-white text-sm font-medium ${getStatusColor(response.status)}`}>
              {response.status}
            </div>
            <span className="ml-2 text-gray-700">{response.statusText}</span>
          </div>
          
          <div className="flex items-center text-sm text-gray-600">
            <span className="mr-1">Time:</span>
            <span className="font-medium">{response.time} ms</span>
          </div>
          
          <div className="flex items-center text-sm text-gray-600">
            <span className="mr-1">Size:</span>
            <span className="font-medium">
              {response.size < 1024 
                ? `${response.size} B` 
                : `${(response.size / 1024).toFixed(1)} KB`}
            </span>
          </div>
        </div>
      </div>
      
      <div className="flex border-b border-gray-200">
        <Tab
          isActive={activeTab === 'body'}
          onClick={() => setActiveTab('body')}
          label="Response"
        />
        <Tab
          isActive={activeTab === 'headers'}
          onClick={() => setActiveTab('headers')}
          label="Headers"
        />
      </div>
      
      <div>
        {activeTab === 'body' && (
          <pre className="p-4 font-mono text-sm overflow-auto max-h-96 whitespace-pre-wrap break-words text-gray-800 bg-gray-50">
            {formattedBody()}
          </pre>
        )}
        
        {activeTab === 'headers' && (
          <div className="p-4">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left py-2 font-medium text-gray-700">Name</th>
                  <th className="text-left py-2 font-medium text-gray-700">Value</th>
                </tr>
              </thead>
              <tbody>
                {response.headers.map((header, index) => (
                  <tr key={index} className="border-b border-gray-100">
                    <td className="py-2 text-gray-700 pr-6">{header.key}</td>
                    <td className="py-2 text-gray-900 font-mono break-all">{header.value}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};