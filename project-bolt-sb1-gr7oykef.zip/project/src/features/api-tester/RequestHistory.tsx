import React from 'react';
import { useRequest } from '../../context/RequestContext';
import { Clock, Save, Folder } from 'lucide-react';

export const RequestHistory: React.FC = () => {
  const { requests, currentRequest, setCurrentRequest, saveRequest } = useRequest();

  // Group templates by common telecom APIs
  const telecomTemplates = [
    {
      name: 'Call Records API',
      method: 'GET',
      url: 'https://api.example.com/v1/calls',
    },
    {
      name: 'Subscriber Info',
      method: 'GET',
      url: 'https://api.example.com/v1/subscribers',
    },
    {
      name: 'SIP Registration',
      method: 'POST',
      url: 'https://api.example.com/v1/sip/register',
    },
    {
      name: 'Network Status',
      method: 'GET',
      url: 'https://api.example.com/v1/network/status',
    }
  ];

  // Function to format date
  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const handleTemplateSelect = (template: any) => {
    setCurrentRequest({
      ...currentRequest,
      method: template.method,
      url: template.url,
      name: template.name,
    });
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
      <div className="p-3 border-b border-gray-200 bg-gray-50">
        <div className="flex justify-between items-center">
          <h2 className="text-sm font-medium text-gray-700">History & Templates</h2>
          <button 
            onClick={saveRequest}
            className="text-xs flex items-center gap-1 text-blue-600 hover:text-blue-800"
          >
            <Save className="w-3 h-3" /> Save
          </button>
        </div>
      </div>

      <div className="divide-y divide-gray-100">
        {/* Telecom Templates Section */}
        <div className="p-3">
          <div className="flex items-center gap-2 mb-2 text-xs text-gray-500">
            <Folder className="w-3 h-3" />
            <span>Telecom Templates</span>
          </div>
          <div className="space-y-2">
            {telecomTemplates.map((template, index) => (
              <button
                key={index}
                onClick={() => handleTemplateSelect(template)}
                className="w-full text-left p-2 rounded text-sm hover:bg-gray-50 transition-colors flex items-center"
              >
                <span className={`inline-block w-12 text-xs font-medium ${
                  template.method === 'GET' ? 'text-green-600' : 
                  template.method === 'POST' ? 'text-blue-600' : 
                  template.method === 'PUT' ? 'text-yellow-600' : 
                  template.method === 'DELETE' ? 'text-red-600' : 'text-gray-600'
                }`}>
                  {template.method}
                </span>
                <span className="text-gray-800 truncate">{template.name}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Recent Requests Section */}
        <div className="p-3">
          <div className="flex items-center gap-2 mb-2 text-xs text-gray-500">
            <Clock className="w-3 h-3" />
            <span>Recent Requests</span>
          </div>
          
          {requests.length === 0 ? (
            <div className="text-xs text-gray-500 text-center py-2">
              No saved requests yet
            </div>
          ) : (
            <div className="space-y-2">
              {requests.map((request) => (
                <button
                  key={request.id}
                  onClick={() => setCurrentRequest(request)}
                  className={`w-full text-left p-2 rounded text-sm hover:bg-gray-50 transition-colors ${
                    currentRequest.id === request.id ? 'bg-blue-50' : ''
                  }`}
                >
                  <div className="flex items-center">
                    <span className={`inline-block w-12 text-xs font-medium ${
                      request.method === 'GET' ? 'text-green-600' : 
                      request.method === 'POST' ? 'text-blue-600' : 
                      request.method === 'PUT' ? 'text-yellow-600' : 
                      request.method === 'DELETE' ? 'text-red-600' : 'text-gray-600'
                    }`}>
                      {request.method}
                    </span>
                    <span className="text-gray-800 truncate">{request.name || 'Unnamed Request'}</span>
                  </div>
                  <div className="mt-1 flex justify-between text-xs text-gray-500">
                    <span className="truncate max-w-[70%]">{request.url}</span>
                    <span>{request.updatedAt ? formatDate(request.updatedAt) : formatDate(request.createdAt)}</span>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};