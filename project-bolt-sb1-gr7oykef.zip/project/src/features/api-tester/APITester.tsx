import React from 'react';
import { RequestBuilder } from './RequestBuilder';
import { ResponseViewer } from './ResponseViewer';
import { RequestHistory } from './RequestHistory';

const APITester: React.FC = () => {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
      <div className="lg:col-span-1">
        <RequestHistory />
      </div>
      <div className="lg:col-span-4 grid grid-cols-1 gap-6">
        <RequestBuilder />
        <ResponseViewer />
      </div>
    </div>
  );
};

export default APITester;