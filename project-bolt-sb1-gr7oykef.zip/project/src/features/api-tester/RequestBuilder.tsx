import React, { useState } from 'react';
import { Play, Plus, Trash } from 'lucide-react';
import { useRequest } from '../../context/RequestContext';
import { Tab } from '../../components/Tab';
import { RequestMethod } from '../../types';

export const RequestBuilder: React.FC = () => {
  const { currentRequest, updateRequestField, sendRequest, isLoading } = useRequest();
  const [activeTab, setActiveTab] = useState<'params' | 'headers' | 'body'>('params');

  const handleMethodChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    updateRequestField('method', e.target.value as RequestMethod);
  };

  const handleUrlChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    updateRequestField('url', e.target.value);
  };

  const handleAddParam = () => {
    updateRequestField('params', [
      ...currentRequest.params,
      { key: '', value: '', enabled: true }
    ]);
  };

  const handleParamChange = (index: number, field: 'key' | 'value', value: string) => {
    const updatedParams = [...currentRequest.params];
    updatedParams[index] = { ...updatedParams[index], [field]: value };
    updateRequestField('params', updatedParams);
  };

  const handleParamToggle = (index: number) => {
    const updatedParams = [...currentRequest.params];
    updatedParams[index] = { 
      ...updatedParams[index], 
      enabled: !updatedParams[index].enabled 
    };
    updateRequestField('params', updatedParams);
  };

  const handleRemoveParam = (index: number) => {
    const updatedParams = [...currentRequest.params];
    updatedParams.splice(index, 1);
    updateRequestField('params', updatedParams);
  };

  const handleAddHeader = () => {
    updateRequestField('headers', [
      ...currentRequest.headers,
      { key: '', value: '', enabled: true }
    ]);
  };

  const handleHeaderChange = (index: number, field: 'key' | 'value', value: string) => {
    const updatedHeaders = [...currentRequest.headers];
    updatedHeaders[index] = { ...updatedHeaders[index], [field]: value };
    updateRequestField('headers', updatedHeaders);
  };

  const handleHeaderToggle = (index: number) => {
    const updatedHeaders = [...currentRequest.headers];
    updatedHeaders[index] = { 
      ...updatedHeaders[index], 
      enabled: !updatedHeaders[index].enabled 
    };
    updateRequestField('headers', updatedHeaders);
  };

  const handleRemoveHeader = (index: number) => {
    const updatedHeaders = [...currentRequest.headers];
    updatedHeaders.splice(index, 1);
    updateRequestField('headers', updatedHeaders);
  };

  const handleBodyChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    updateRequestField('body', e.target.value);
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
      <div className="p-4">
        <div className="flex flex-col md:flex-row gap-3">
          <div className="w-full md:w-40">
            <select
              value={currentRequest.method}
              onChange={handleMethodChange}
              className="w-full rounded-md border border-gray-300 px-3 py-2 bg-white text-gray-800 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="GET">GET</option>
              <option value="POST">POST</option>
              <option value="PUT">PUT</option>
              <option value="DELETE">DELETE</option>
              <option value="PATCH">PATCH</option>
              <option value="HEAD">HEAD</option>
              <option value="OPTIONS">OPTIONS</option>
            </select>
          </div>
          
          <div className="flex-1">
            <input
              type="text"
              value={currentRequest.url}
              onChange={handleUrlChange}
              placeholder="Enter request URL"
              className="w-full rounded-md border border-gray-300 px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
          
          <div>
            <button
              onClick={sendRequest}
              disabled={isLoading || !currentRequest.url}
              className={`flex items-center gap-1 rounded-md px-4 py-2 text-white transition-colors ${
                isLoading || !currentRequest.url 
                  ? 'bg-gray-400 cursor-not-allowed' 
                  : 'bg-blue-600 hover:bg-blue-700'
              }`}
            >
              <Play className="w-4 h-4" />
              <span>Send</span>
            </button>
          </div>
        </div>
      </div>
      
      <div className="border-t border-gray-200">
        <div className="flex border-b border-gray-200">
          <Tab
            isActive={activeTab === 'params'}
            onClick={() => setActiveTab('params')}
            label="Params"
          />
          <Tab
            isActive={activeTab === 'headers'}
            onClick={() => setActiveTab('headers')}
            label="Headers"
          />
          <Tab
            isActive={activeTab === 'body'}
            onClick={() => setActiveTab('body')}
            label="Body"
          />
        </div>
        
        <div className="p-4">
          {activeTab === 'params' && (
            <div>
              <div className="flex justify-between mb-3">
                <h3 className="text-sm font-medium text-gray-700">Query Parameters</h3>
                <button
                  onClick={handleAddParam}
                  className="text-xs flex items-center gap-1 text-blue-600 hover:text-blue-800"
                >
                  <Plus className="w-3 h-3" /> Add Parameter
                </button>
              </div>
              
              {currentRequest.params.length === 0 ? (
                <div className="text-sm text-gray-500 text-center py-4">
                  No parameters added yet
                </div>
              ) : (
                <div className="space-y-2">
                  {currentRequest.params.map((param, index) => (
                    <div key={index} className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={param.enabled}
                        onChange={() => handleParamToggle(index)}
                        className="h-4 w-4 text-blue-600 rounded"
                      />
                      <input
                        type="text"
                        value={param.key}
                        onChange={(e) => handleParamChange(index, 'key', e.target.value)}
                        placeholder="Key"
                        className="flex-1 rounded-md border border-gray-300 px-3 py-1 text-sm"
                      />
                      <input
                        type="text"
                        value={param.value}
                        onChange={(e) => handleParamChange(index, 'value', e.target.value)}
                        placeholder="Value"
                        className="flex-1 rounded-md border border-gray-300 px-3 py-1 text-sm"
                      />
                      <button
                        onClick={() => handleRemoveParam(index)}
                        className="text-gray-500 hover:text-red-600"
                      >
                        <Trash className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
          
          {activeTab === 'headers' && (
            <div>
              <div className="flex justify-between mb-3">
                <h3 className="text-sm font-medium text-gray-700">Headers</h3>
                <button
                  onClick={handleAddHeader}
                  className="text-xs flex items-center gap-1 text-blue-600 hover:text-blue-800"
                >
                  <Plus className="w-3 h-3" /> Add Header
                </button>
              </div>
              
              {currentRequest.headers.length === 0 ? (
                <div className="text-sm text-gray-500 text-center py-4">
                  No headers added yet
                </div>
              ) : (
                <div className="space-y-2">
                  {currentRequest.headers.map((header, index) => (
                    <div key={index} className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={header.enabled}
                        onChange={() => handleHeaderToggle(index)}
                        className="h-4 w-4 text-blue-600 rounded"
                      />
                      <input
                        type="text"
                        value={header.key}
                        onChange={(e) => handleHeaderChange(index, 'key', e.target.value)}
                        placeholder="Key"
                        className="flex-1 rounded-md border border-gray-300 px-3 py-1 text-sm"
                      />
                      <input
                        type="text"
                        value={header.value}
                        onChange={(e) => handleHeaderChange(index, 'value', e.target.value)}
                        placeholder="Value"
                        className="flex-1 rounded-md border border-gray-300 px-3 py-1 text-sm"
                      />
                      <button
                        onClick={() => handleRemoveHeader(index)}
                        className="text-gray-500 hover:text-red-600"
                      >
                        <Trash className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
          
          {activeTab === 'body' && (
            <div>
              <h3 className="text-sm font-medium text-gray-700 mb-3">Request Body</h3>
              <textarea
                value={currentRequest.body}
                onChange={handleBodyChange}
                placeholder={`// Enter request body (JSON, XML, etc.)\n{\n  "key": "value"\n}`}
                className="w-full h-64 font-mono rounded-md border border-gray-300 px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
          )}
        </div>
      </div>
    </div>
  );
};