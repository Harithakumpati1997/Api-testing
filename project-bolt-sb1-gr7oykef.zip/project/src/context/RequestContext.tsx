import React, { createContext, useState, useContext, ReactNode } from 'react';
import { RequestMethod, RequestData, ResponseData } from '../types';

interface RequestContextType {
  requests: RequestData[];
  currentRequest: RequestData;
  response: ResponseData | null;
  isLoading: boolean;
  setCurrentRequest: (request: RequestData) => void;
  updateRequestField: (field: keyof RequestData, value: any) => void;
  sendRequest: () => Promise<void>;
  saveRequest: () => void;
  clearResponse: () => void;
}

const defaultRequest: RequestData = {
  id: 'default',
  name: 'New Request',
  url: '',
  method: 'GET',
  headers: [],
  body: '',
  params: [],
  createdAt: new Date().toISOString(),
};

const RequestContext = createContext<RequestContextType | undefined>(undefined);

export const RequestProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [requests, setRequests] = useState<RequestData[]>([]);
  const [currentRequest, setCurrentRequest] = useState<RequestData>(defaultRequest);
  const [response, setResponse] = useState<ResponseData | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const updateRequestField = (field: keyof RequestData, value: any) => {
    setCurrentRequest((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const sendRequest = async () => {
    setIsLoading(true);
    setResponse(null);
    
    const startTime = performance.now();
    
    try {
      // Prepare request URL with query params
      let url = currentRequest.url;
      if (currentRequest.params && currentRequest.params.length > 0) {
        const queryParams = currentRequest.params
          .filter(param => param.key && param.enabled)
          .map(param => `${encodeURIComponent(param.key)}=${encodeURIComponent(param.value || '')}`)
          .join('&');
          
        if (queryParams) {
          url += url.includes('?') ? `&${queryParams}` : `?${queryParams}`;
        }
      }
      
      // Prepare headers
      const headers: Record<string, string> = {};
      currentRequest.headers.forEach(header => {
        if (header.key && header.enabled) {
          headers[header.key] = header.value || '';
        }
      });
      
      // Make the request
      const fetchOptions: RequestInit = {
        method: currentRequest.method,
        headers,
      };
      
      // Add body for appropriate methods
      if (['POST', 'PUT', 'PATCH'].includes(currentRequest.method) && currentRequest.body) {
        fetchOptions.body = currentRequest.body;
      }
      
      const res = await fetch(url, fetchOptions);
      const endTime = performance.now();
      
      // Parse response based on content type
      const contentType = res.headers.get('content-type') || '';
      let data: any;
      
      if (contentType.includes('application/json')) {
        data = await res.json();
      } else {
        data = await res.text();
      }
      
      // Create response data
      const responseData: ResponseData = {
        status: res.status,
        statusText: res.statusText,
        headers: Array.from(res.headers.entries()).map(([key, value]) => ({ key, value })),
        body: data,
        time: Math.round(endTime - startTime),
        size: JSON.stringify(data).length,
        contentType,
      };
      
      setResponse(responseData);
    } catch (error) {
      console.error('Request failed:', error);
      setResponse({
        status: 0,
        statusText: 'Error',
        headers: [],
        body: { error: error instanceof Error ? error.message : 'Failed to fetch' },
        time: Math.round(performance.now() - startTime),
        size: 0,
        contentType: 'application/json',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const saveRequest = () => {
    const requestToSave = {
      ...currentRequest,
      id: currentRequest.id === 'default' ? `req_${Date.now()}` : currentRequest.id,
      updatedAt: new Date().toISOString(),
    };
    
    setRequests(prev => {
      const exists = prev.some(req => req.id === requestToSave.id);
      if (exists) {
        return prev.map(req => req.id === requestToSave.id ? requestToSave : req);
      } else {
        return [...prev, requestToSave];
      }
    });
    
    setCurrentRequest(requestToSave);
  };

  const clearResponse = () => {
    setResponse(null);
  };

  return (
    <RequestContext.Provider
      value={{
        requests,
        currentRequest,
        response,
        isLoading,
        setCurrentRequest,
        updateRequestField,
        sendRequest,
        saveRequest,
        clearResponse,
      }}
    >
      {children}
    </RequestContext.Provider>
  );
};

export const useRequest = () => {
  const context = useContext(RequestContext);
  if (context === undefined) {
    throw new Error('useRequest must be used within a RequestProvider');
  }
  return context;
};