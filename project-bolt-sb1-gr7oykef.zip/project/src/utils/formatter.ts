/**
 * Format JSON for display in the UI
 */
export function formatJson(json: any): string {
  try {
    return JSON.stringify(json, null, 2);
  } catch (error) {
    return String(json);
  }
}

/**
 * Highlight syntax (placeholder for future enhancement)
 */
export function highlightSyntax(code: string, language: string): string {
  // In a real implementation, this would use a library like highlight.js
  // For now, just return the code
  return code;
}

/**
 * Format content based on content type
 */
export function formatContent(content: any, contentType: string): string {
  if (contentType.includes('application/json')) {
    return formatJson(content);
  }
  
  if (contentType.includes('application/xml') || contentType.includes('text/xml')) {
    // For XML we would use a proper formatter
    // For now just return as string
    return typeof content === 'string' ? content : String(content);
  }
  
  return typeof content === 'string' ? content : String(content);
}