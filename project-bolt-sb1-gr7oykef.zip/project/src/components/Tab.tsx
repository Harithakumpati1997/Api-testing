import React from 'react';

interface TabProps {
  isActive: boolean;
  onClick: () => void;
  label: string;
}

export const Tab: React.FC<TabProps> = ({ isActive, onClick, label }) => {
  return (
    <button
      onClick={onClick}
      className={`px-4 py-2 text-sm transition-colors border-b-2 ${
        isActive
          ? 'border-blue-600 text-blue-600'
          : 'border-transparent text-gray-600 hover:text-gray-900 hover:border-gray-300'
      }`}
    >
      {label}
    </button>
  );
};