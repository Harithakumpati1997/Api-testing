import React, { ReactNode } from 'react';
import { Zap } from 'lucide-react';

interface LayoutProps {
  children: ReactNode;
}

export const Layout: React.FC<LayoutProps> = ({ children }) => {
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <header className="bg-white border-b border-gray-200 shadow-sm">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Zap className="h-6 w-6 text-blue-600" />
            <h1 className="text-xl font-semibold text-gray-900">TelecomAPI Tester</h1>
          </div>
          <nav>
            <ul className="flex space-x-4">
              <li>
                <button className="px-3 py-2 text-sm text-gray-700 hover:text-blue-600 transition-colors">
                  Docs
                </button>
              </li>
              <li>
                <button className="px-3 py-2 text-sm bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors">
                  Save
                </button>
              </li>
            </ul>
          </nav>
        </div>
      </header>
      <main className="flex-1 container mx-auto px-4 py-6">
        {children}
      </main>
      <footer className="bg-white border-t border-gray-200 py-4">
        <div className="container mx-auto px-4 text-center text-sm text-gray-500">
          &copy; {new Date().getFullYear()} TelecomAPI Tester. All rights reserved.
        </div>
      </footer>
    </div>
  );
};