describe('Telecom API Tester', () => {
  beforeEach(() => {
    cy.visit('/');
  });

  it('should load the application successfully', () => {
    cy.get('h1').should('contain', 'TelecomAPI Tester');
    cy.get('button').contains('Send').should('be.disabled');
  });

  it('should handle GET request workflow', () => {
    // Select GET method and enter URL
    cy.get('select').select('GET');
    cy.get('input[placeholder="Enter request URL"]')
      .type('https://api.example.com/v1/network/status');
    cy.get('button').contains('Send').should('be.enabled').click();

    // Verify response handling
    cy.get('pre').should('exist');
    cy.get('[class*="text-green-500"]').should('exist');
  });

  it('should manage request parameters', () => {
    // Add and verify query parameter
    cy.contains('button', 'Add Parameter').click();
    cy.get('input[placeholder="Key"]').type('region');
    cy.get('input[placeholder="Value"]').type('us-east');
    
    // Verify parameter is added to URL when sent
    cy.get('input[placeholder="Enter request URL"]')
      .type('https://api.example.com/v1/network/status');
    cy.get('button').contains('Send').click();
    
    cy.url().should('include', 'region=us-east');
  });

  it('should handle request history', () => {
    // Make a request
    cy.get('select').select('GET');
    cy.get('input[placeholder="Enter request URL"]')
      .type('https://api.example.com/v1/network/status');
    cy.get('button').contains('Send').click();
    
    // Save request
    cy.contains('button', 'Save').click();
    
    // Verify request appears in history
    cy.contains('Recent Requests')
      .parent()
      .find('button')
      .should('have.length.at.least', 1);
  });

  it('should validate request inputs', () => {
    // Test URL validation
    cy.get('button').contains('Send').should('be.disabled');
    cy.get('input[placeholder="Enter request URL"]')
      .type('invalid-url');
    cy.get('button').contains('Send').should('be.disabled');
    
    // Test valid URL
    cy.get('input[placeholder="Enter request URL"]')
      .clear()
      .type('https://api.example.com');
    cy.get('button').contains('Send').should('be.enabled');
  });

  it('should handle different HTTP methods', () => {
    const methods = ['GET', 'POST', 'PUT', 'DELETE', 'PATCH'];
    methods.forEach(method => {
      cy.get('select').select(method);
      cy.get('select').should('have.value', method);
    });
  });

  it('should handle request headers', () => {
    cy.contains('Headers').click();
    cy.contains('button', 'Add Header').click();
    
    // Add authorization header
    cy.get('input[placeholder="Key"]').type('Authorization');
    cy.get('input[placeholder="Value"]').type('Bearer test-token');
    
    // Verify header is included in request
    cy.get('input[placeholder="Enter request URL"]')
      .type('https://api.example.com/v1/secure');
    cy.get('button').contains('Send').click();
    
    // Check headers tab in response
    cy.contains('Headers').click();
    cy.contains('Authorization').should('exist');
  });
});