describe('Telecom API Templates', () => {
  beforeEach(() => {
    cy.visit('/');
  });

  it('should load predefined templates', () => {
    cy.contains('Telecom Templates').should('exist');
    cy.contains('Call Records API').should('exist');
    cy.contains('Subscriber Info').should('exist');
    cy.contains('SIP Registration').should('exist');
    cy.contains('Network Status').should('exist');
  });

  it('should apply template when selected', () => {
    cy.contains('Call Records API').click();
    cy.get('input[placeholder="Enter request URL"]')
      .should('have.value', 'https://api.example.com/v1/calls');
    cy.get('select').should('have.value', 'GET');
  });

  it('should handle template modifications', () => {
    // Select template
    cy.contains('Call Records API').click();
    
    // Modify request
    cy.get('button').contains('Add Parameter').click();
    cy.get('input[placeholder="Key"]').type('limit');
    cy.get('input[placeholder="Value"]').type('100');
    
    // Save modified template
    cy.contains('button', 'Save').click();
    
    // Verify saved in history
    cy.contains('Recent Requests')
      .parent()
      .contains('Call Records API')
      .should('exist');
  });
});